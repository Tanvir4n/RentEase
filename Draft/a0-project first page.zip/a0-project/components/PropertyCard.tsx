import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function PropertyCard({ property, onPress, featured }) {
  return (
    <TouchableOpacity
      style={[
        styles.card,
        featured ? styles.featuredCard : styles.regularCard,
      ]}
      onPress={onPress}
    >
      <Image source={{ uri: property.imageUrl }} style={styles.image} />
      <View style={styles.content}>
        <View style={styles.priceRow}>
          <Text style={styles.price}>${property.price}</Text>
          <Text style={styles.period}>/month</Text>
        </View>
        <Text style={styles.title} numberOfLines={1}>{property.title}</Text>
        <Text style={styles.location}>{property.location}</Text>
        <View style={styles.details}>
          <View style={styles.detail}>
            <Ionicons name="bed-outline" size={16} color="#666" />
            <Text style={styles.detailText}>{property.bedrooms} beds</Text>
          </View>
          <View style={styles.detail}>
            <Ionicons name="water-outline" size={16} color="#666" />
            <Text style={styles.detailText}>{property.bathrooms} baths</Text>
          </View>
          <View style={styles.detail}>
            <Ionicons name="star" size={16} color="#FFD700" />
            <Text style={styles.detailText}>{property.rating} ({property.reviews})</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  featuredCard: {
    width: 300,
    marginRight: 15,
  },
  regularCard: {
    marginHorizontal: 20,
    marginBottom: 15,
  },
  image: {
    width: '100%',
    height: 200,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  content: {
    padding: 15,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  price: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  period: {
    fontSize: 14,
    color: '#666',
    marginLeft: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginTop: 8,
  },
  location: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  details: {
    flexDirection: 'row',
    marginTop: 12,
    justifyContent: 'space-between',
  },
  detail: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  detailText: {
    marginLeft: 4,
    fontSize: 14,
    color: '#666',
  },
});