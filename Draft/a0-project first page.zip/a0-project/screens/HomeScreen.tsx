import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import PropertyCard from '../components/PropertyCard';
import SearchBar from '../components/SearchBar';
import FilterModal from '../components/FilterModal';

const MOCK_PROPERTIES = [
  {
    id: '1',
    title: 'Modern Downtown Apartment',
    price: 2500,
    location: 'New York, NY',
    bedrooms: 2,
    bathrooms: 2,
    imageUrl: 'https://api.a0.dev/assets/image?text=modern%20luxury%20apartment%20interior&aspect=16:9',
    rating: 4.8,
    reviews: 24,
  },
  {
    id: '2',
    title: 'Luxury Beach House',
    price: 3800,
    location: 'Miami Beach, FL',
    bedrooms: 3,
    bathrooms: 2.5,
    imageUrl: 'https://api.a0.dev/assets/image?text=luxury%20beach%20house%20with%20pool&aspect=16:9',
    rating: 4.9,
    reviews: 36,
  },
];

export default function HomeScreen({ navigation }) {
  const [showFilters, setShowFilters] = useState(false);  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.logo}>RentEase</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Ionicons name="person-circle-outline" size={32} color="#333" />
        </TouchableOpacity>
      </View>

      <SearchBar 
        onFilterPress={() => setShowFilters(true)} 
        onMapPress={() => navigation.navigate('Map')}
        isMapView={false}
      />

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Properties</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.featuredList}
          >
            {MOCK_PROPERTIES.map((property) => (
              <PropertyCard
                key={property.id}
                property={property}
                onPress={() => navigation.navigate('PropertyDetails', { propertyId: property.id })}
                featured
              />
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Listings</Text>
          {MOCK_PROPERTIES.map((property) => (
            <PropertyCard
              key={property.id}
              property={property}
              onPress={() => navigation.navigate('PropertyDetails', { propertyId: property.id })}
            />
          ))}
        </View>
      </ScrollView>

      <FilterModal visible={showFilters} onClose={() => setShowFilters(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#fff',
  },
  logo: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    flex: 1,
  },
  section: {
    marginVertical: 15,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginLeft: 20,
    marginBottom: 15,
    color: '#333',
  },
  featuredList: {
    paddingLeft: 20,
  },
});