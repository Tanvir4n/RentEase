import React, { useState } from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import { SafeAreaView } from 'react-native-safe-area-context';
import PropertyCard from '../components/PropertyCard';
import SearchBar from '../components/SearchBar';
import FilterModal from '../components/FilterModal';

const MOCK_PROPERTIES = [
  {
    id: '1',
    title: 'Modern Downtown Apartment',
    price: 2500,
    location: 'New York, NY',
    bedrooms: 2,
    bathrooms: 2,
    imageUrl: 'https://api.a0.dev/assets/image?text=modern%20luxury%20apartment%20interior&aspect=16:9',
    rating: 4.8,
    reviews: 24,
    coordinate: {
      latitude: 40.7128,
      longitude: -74.0060,
    },
  },
  {
    id: '2',
    title: 'Luxury Beach House',
    price: 3800,
    location: 'Miami Beach, FL',
    bedrooms: 3,
    bathrooms: 2.5,
    imageUrl: 'https://api.a0.dev/assets/image?text=luxury%20beach%20house%20with%20pool&aspect=16:9',
    rating: 4.9,
    reviews: 36,
    coordinate: {
      latitude: 25.7617,
      longitude: -80.1918,
    },
  },
];

export default function MapScreen({ navigation }) {
  const [showFilters, setShowFilters] = useState(false);
  const [selectedProperty, setSelectedProperty] = useState(null);

  const initialRegion = {
    latitude: 40.7128,
    longitude: -74.0060,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  };

  return (
    <SafeAreaView style={styles.container}>
      <SearchBar 
        onFilterPress={() => setShowFilters(true)}
        onMapPress={() => navigation.navigate('Home')}
        isMapView={true}
      />
      
      <View style={styles.mapContainer}>
        <MapView
          style={styles.map}
          initialRegion={initialRegion}
          showsUserLocation={true}
        >
          {MOCK_PROPERTIES.map((property) => (
            <Marker
              key={property.id}
              coordinate={property.coordinate}
              onPress={() => setSelectedProperty(property)}
            >
              <View style={styles.markerContainer}>
                <View style={styles.marker}>
                  <View style={styles.markerPrice}>
                    <View style={styles.priceTag}>
                      <View style={styles.priceContainer}>
                        <View style={styles.price}>
                          <Text style={styles.priceText}>${property.price}</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
              <Callout>
                <View style={styles.callout}>
                  <PropertyCard
                    property={property}
                    onPress={() => navigation.navigate('PropertyDetails', { propertyId: property.id })}
                    featured={false}
                  />
                </View>
              </Callout>
            </Marker>
          ))}
        </MapView>
      </View>

      <FilterModal visible={showFilters} onClose={() => setShowFilters(false)} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    width: Dimensions.get('window').width,
    height: '100%',
  },
  markerContainer: {
    alignItems: 'center',
  },
  marker: {
    backgroundColor: '#007AFF',
    padding: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#fff',
  },
  markerPrice: {
    minWidth: 60,
    alignItems: 'center',
  },
  priceTag: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  priceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  price: {
    paddingHorizontal: 4,
  },
  priceText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 14,
  },
  callout: {
    width: 300,
    height: 300,
  },
});